﻿

1. Created Models and db context
2. Created a seed for local database  // uncomment configurations and delete or rename database to reset
3. added controllers with CRUD (create, read, update, delete) 
3. added try/catch for updating database queries
4. created views that display information from multiple tables
5. added sorting and search box for the data
6. added page numbering on the footer 
7. enabled migrations, 
7. Run seed with migrations
8. Serverside Data Validation for models and formatting
9. Assignable ID's', like unique course ID's
10. Eager loading for Instructors,Courses and related Departments
11. Concurency and Error messages in Departments

